﻿本作品采用知识共享 署名-非商业性使用-相同方式共享 3.0 未本地化版本 许可协议进行许可
访问 http://creativecommons.org/licenses/by-nc-sa/3.0/ 查看该许可协议
==============

版权所有：
@老潘orz  wasdpkj@hotmail.com
==============

Microduino-IDE
==============
Microduino Getting start:
http://www.microduino.cc/download/

Microduino IDE Support：
https://github.com/wasdpkj/Microduino-IDE-Support/

==============
Microduino wiki:
http://wiki.microduino.cc

==============
E-mail:
Kejia Pan
pankejia@microduino.cc

==============
Weibo:
@老潘orz